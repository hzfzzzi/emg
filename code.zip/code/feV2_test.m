[e,l] = pre_process(3,true);
f = feature_extrationV3(e);